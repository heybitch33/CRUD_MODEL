//
//  ModelSwift.swift
//  Model
//
//  Created by Ivan Yavtushenko on 01.04.2021.
//


//Make CRUD

import UIKit

struct Project {
  
  let id: UUID
  let name: String
  let description: String
  let startDate: Date
  let endDate: Date
  let assignee: User
  let completionStatus: CompletionStatus
  let tasks: [Task]
  let comments: [Comment]
  let attachments: [Attachment]
  let projectAvatar: String

}

struct Task {
  
  let id: UUID
  let name: String
  let description: String
  let startDate: String
  let endDate: String
  let assignee: User
  let completionStatus: CompletionStatus
  let comments: [Comment]
  let trackedTime: TimeInterval
  let attachments: [Attachment]
  let notifications: [Notification]
  let tags: [Tag]
  let checklistItems: [ChecklistItem]
  
}

enum CompletionStatus {
  case new
  case inProgress(Int)
  case done
}

struct User {
  
  let id: UUID
  let fullName: String
  let nickName: String
  let jobTitle: String
  let bio: String
  let email: String
  let groups: [UserGroup]
  let avatar: String
  let phone: String
  let address: String
  let friends: [UUID]
  let projects: [UUID]
  let tasks: [UUID]
  let socialLinks: [SocialLink]
  let lastActive: Date
  
}

struct Comment {
  
  let id: UUID
  let owner: UUID
  let text: String
  let date: Date
  let mentions: [UUID]
  
}

struct Attachment {
  
  let id: UUID
  let attachmentType: AttachmentType
  let link: String
  let size: Int
  let uploadDate: Date
  let owner: UUID
  
}

enum AttachmentType {
  
  case image((name: String, icon: UIImage))
  case pdf((name: String, icon: UIImage))
  
}

struct Notification {
  
  let id: UUID
  let name: String
  let fireTime: Date
  
}

struct Tag {
  
  let id: UUID
  let name: String
  let color: UIColor
  
}

struct UserGroup {
  
  let id: UUID
  let name: String
  
}

struct SocialLink {
  
  let id: UUID
  
}

struct ChecklistItem {
  
  let id: UUID
  
}
